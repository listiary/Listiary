Back-end bots and tooling for the Listiary project Radiowatch and Sepia KB.

This is not everything - as there are some large files - but this is the important bits and the know how.
Most tools are in encrypted archives, as they have not been open-sourced yet.
